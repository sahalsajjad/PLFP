Team Members: Sahal Sajjad (IS201301021), Ashish Verma(IS201201003)

To install and set up go
please execute installer.sh via the following command
'sh installer.sh'

Set up for Tools and libraries are downloaded and PATH is set up in the script file. 
Also gccgo compiler is also installed.

Now, in order to execute p*, execute 
'go run p*.go'

